#include "ros/ros.h"
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include "geometry_msgs/PoseStamped.h"
#include <iostream>

using namespace ros;



tf::StampedTransform map2odom_ ;

void gridPoseCallback(const geometry_msgs::PoseStamped grid_pose)
{
	ros::Duration transform_tolerance_ (0.0);
	tf::TransformListener listener;
	try
    {  
		ros::Time now = ros::Time(0);
		tf::Transform map2base = 
		tf::Transform(tf::Quaternion(grid_pose.pose.orientation.x, grid_pose.pose.orientation.y, grid_pose.pose.orientation.z, grid_pose.pose.orientation.w),
		   	 							tf::Vector3(grid_pose.pose.position.x, grid_pose.pose.position.y,grid_pose.pose.position.z));

		tf::StampedTransform odom2base;
		// printf("base2map,%f,%f,%f\n%f,%f,%f\n",base2map.getRotation()[0],base2map.getRotation()[1],base2map.getRotation()[2],base2map.getOrigin()[0],base2map.getOrigin()[1],base2map.getOrigin()[2]);									  
		listener.waitForTransform("odom","base_link",now,ros::Duration(2));
		listener.lookupTransform("/odom", "/base_link",now, odom2base);
		tf::Transform base2odom = odom2base.inverse();
		tf::Transform base2map = map2base.inverse();
		// printf("base2odom,%f,%f,%f\n%f,%f,%f\n",base2odom.getRotation()[0],base2odom.getRotation()[1],base2odom.getRotation()[2],base2odom.getOrigin()[0],base2odom.getOrigin()[1],base2odom.getOrigin()[2]);									  
		ROS_INFO("%lf",now.toSec());
		tf::Transform latest_tf;
		latest_tf = base2map.inverse()*base2odom;

	ros::Time transform_expiration = (ros::Time::now() +transform_tolerance_);
	tf::StampedTransform map2odom(latest_tf,
										transform_expiration,
										"map", "odom");
    map2odom_ = map2odom;
	printf("[%lf] send transform from map to odom!\n",transform_expiration.toSec());
	}
	catch (tf::TransformException &ex) {
	ROS_ERROR("%s",ex.what());
	// ros::Duration(1.0).sleep();
	}

}


int main(int argc, char** argv){
    init(argc, argv, "map2odom_Node");    
    NodeHandle n;
	
	tf::TransformBroadcaster broadcaster;
    Subscriber gridpose_sub = n.subscribe("/grid_pose", 5, gridPoseCallback);
    //发送消息的频率为2Hz， 1秒发2个，周期为500ms
    Rate loop_rate(1);
    while(ok()){
        broadcaster.sendTransform(map2odom_);
         //靠sleep（）函数保证连续两个消息之间的时间恰好为一个周期
	    loop_rate.sleep();
    }
    return 0;
}